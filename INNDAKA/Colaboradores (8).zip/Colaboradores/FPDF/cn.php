<?php
$mysqli = new mysqli("LocalHost", "root","","inndaka2");
