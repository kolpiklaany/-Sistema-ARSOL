// Obtén el botón por su ID
let btnBuscar = document.getElementById('rum-Btn-Buscar');

// Agrega un event listener para el clic en el botón
btnBuscar.addEventListener('click', function() {
    // Cambia la ubicación del navegador a la nueva página
    window.location.href = 'Buscador.php'; // Reemplaza 'nueva_pagina.html' con la URL de la página a la que deseas redirigir
});


